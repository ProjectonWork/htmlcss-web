module.exports = `
Usage: true [OPTION]
Do nothing, successfully

This command simply exits with status 0 (success).

      --help   display this help and exit

Report true bugs to <https://github.com/dthree/cash>
Cash home page: <http://cash.js.org/>
`;
