module.exports = `
Usage: pwd [-LP]
Print the name of the current working directory.

      --help        display this help and exit

Exit status:
  0   if OK,
  1   if an invalid option is given or the current directory
      cannot be read.

Report pwd bugs to <https://github.com/dthree/cash>
Cash home page: <http://cash.js.org/>
`;
