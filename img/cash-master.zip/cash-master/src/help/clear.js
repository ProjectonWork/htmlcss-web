module.exports = `
Usage: clear
Clear the terminal screen

      --help        display this help and exit

Clear ignores any command-line parameters that may be present.

Report clear bugs to <https://github.com/dthree/cash>
Cash home page: <http://cash.js.org/>
`;
