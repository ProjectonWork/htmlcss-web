module.exports = `
Usage: false [OPTION]
Do nothing, unsuccessfully

This command simply exits with status 1 (failure).

      --help   display this help and exit

Report false bugs to <https://github.com/dthree/cash>
Cash home page: <http://cash.js.org/>
`;
