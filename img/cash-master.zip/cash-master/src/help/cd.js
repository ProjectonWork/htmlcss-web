module.exports = `
Usage: cd [DIR]...
Change the cash working directory.

Change the current directory to DIR.  The default DIR is the value of the
HOME shell variable.

Report cd bugs to <https://github.com/dthree/cash>
Cash home page: <http://cash.js.org/>
`;
