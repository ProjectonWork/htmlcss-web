'use strict';

module.exports = require('vorpal-less');
