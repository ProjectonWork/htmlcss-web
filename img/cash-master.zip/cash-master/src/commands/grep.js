'use strict';

module.exports = require('vorpal-grep');
