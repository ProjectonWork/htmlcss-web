'use strict';

const cash = require('../../dist/index.js');


let result = cash('fooo!!!!!');

console.log('!!!!!!!!!' + result);
console.log('----------------');